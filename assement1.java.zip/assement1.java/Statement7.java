class Statement7 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\"Type of Programming languages\"");
		Thread.sleep(2000);
		System.out.print("\n\nProcedural Programming languages,");
		Thread.sleep(2000);
		System.out.print("Functional Programming languages,");
		Thread.sleep(2000);
		System.out.print("Object-oriented Programming languages,");
		Thread.sleep(2000);
		System.out.print("Logic Programming languages.");
		
	}
}

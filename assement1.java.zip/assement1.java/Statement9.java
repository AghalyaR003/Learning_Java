class Statement9 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\t\"TOOLS IN JAVA PROGRAMMING LANGUAGE\"");
		Thread.sleep(2000);
		System.out.println("1.Apache Maven\n2.GIT\n3.Jenkins\n4.JIRA\n5.Docker\n6.Gradle");
		System.out.print("7.Selenium");
	}
}

class Statement8 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\t\"Platforms of java\"");
		Thread.sleep(2000);
		System.out.println("Java Platform\nStandard Edition\nEnterprise Edition");
		System.out.print("Micro Edition");
	}
}

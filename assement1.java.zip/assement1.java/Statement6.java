class Statement6 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\t\tHistory of java");
		Thread.sleep(5000);
		System.out.print("Father of java \"James Goslings\".Java is a coffee seed name.");
		Thread.sleep(2000);
		System.out.print("Currently java is own by\"Oracale\".");

	}
}

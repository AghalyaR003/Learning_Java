class Statement10 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\"Application of java\"");
		Thread.sleep(2000);
		System.out.println("Moblie Application\nArtifical intelligence\nweb Application\nBig Data technology");
		System.out.print("Business Application");

	}
}

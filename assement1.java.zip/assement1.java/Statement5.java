class Statement5 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\"What is file handling?\"");
		Thread.sleep(3000);
		System.out.print("The process of\n\tCreating\n\twriting\n\tReading\n\tUpdating\n\tclosing\n\tDeleting\nthe file is called file handling.");
		
	}
}

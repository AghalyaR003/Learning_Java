class Statement2 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\tLANGUAGE");
		System.out.println("A medium to achieve the communication between two parties.");
		Thread.sleep(3000);
		System.out.println("\"Types of language\"");
		Thread.sleep(1000);
		System.out.println("1.Low level/Binary language.\n2.Mid-level/Assembley language.\n3.High level/Programming language.");
		Thread.sleep(1000);
		System.out.println("Low-level\n Combination of 0 and 1.");
		Thread.sleep(1000);
		System.out.println("Mid-level\n It contains some predefined words called as Mnimonics.\n Translator to convented Assembly level language into binary language.");
		Thread.sleep(1000);
		System.out.print("High-level\nIt is programmer Friendly language.");
		
	}
}

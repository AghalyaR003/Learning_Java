class Statement3 
{
	public static void main(String[] args) throws Exception
	{
		System.out.println("\t\t\t\tImportant Teminologyies ");
		Thread.sleep(1000);
		System.out.println("1.\"JDK:\"Java Development kit.\n2.\"JRE:\"Java Runtime Environment.\n3.\"JVM:\"Java virtual machine.");
		System.out.print("4.\"JIT:\"Just in time compiler.\n5.\".jar\"Java Archive.");
		
	}
}
